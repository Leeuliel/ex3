#include "HealthPoints.h"

// operator << for printing
std::ostream& operator<<(std::ostream& os, const HealthPoints& hp){

    os << hp.m_current_hp << "(" << hp.m_max_hp << ")";
    return os;

}

// as explained in the lecture
HealthPoints& HealthPoints::operator +=(int hp){

    if (m_current_hp + hp > m_max_hp) {

        m_current_hp = m_max_hp;

    } else {

        m_current_hp += hp;
    }
    if (m_current_hp < 0) 
    {
        m_current_hp = 0;
    }

    return *this;
}


// using the already implemented += oprator
HealthPoints HealthPoints::operator +(int hp) const
{
    HealthPoints current_hp(*this);

    return (current_hp += hp);
}

// turning sided
HealthPoints operator+(const int& hp, const HealthPoints& other) 
{

    return (other + hp);

}

// as explained in the lecture
HealthPoints& HealthPoints::operator -=(int hp){


    if (m_current_hp - hp > m_max_hp) {

        m_current_hp = m_max_hp;

    } else {

        m_current_hp -= hp;

    }
    if (m_current_hp < 0) 
    {
        m_current_hp = 0;
    }

    return *this;
}

// using the already implemented -= oprator
HealthPoints HealthPoints::operator-(int hp) const
{
    HealthPoints current_hp(*this);

    return (current_hp -= hp);
}

// == oprator as requested in the ex3
bool operator==(const HealthPoints& hp1, const HealthPoints& hp2)
{
    return (hp1.get_current_hp() == hp2.get_current_hp());
}

// the ! of the already implemented == oprator
bool operator!=(const HealthPoints& hp1, const HealthPoints& hp2)
{
    return (!(hp1 == hp2));
}

// no need to explain
bool operator<=(const HealthPoints& hp1, const HealthPoints& hp2){

    bool result = hp1.get_current_hp() <= hp2.get_current_hp();

    return result;
    
} 
// no need to explain
bool operator >(const HealthPoints& hp1, const HealthPoints& hp2){ // > will be !<=

    return (!(hp1 <= hp2));

}
// no need to explain

bool operator>=(const HealthPoints& hp1, const HealthPoints& hp2){


    bool result = hp1.get_current_hp() >= hp2.get_current_hp();

    return result;


}
// no need to explain
bool operator <(const HealthPoints& hp1, const HealthPoints& hp2){ // < will be !>=

    return (!(hp1 >= hp2));

}


