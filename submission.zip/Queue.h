#ifndef _QUEUE_H
#define _QUEUE_H
#include <iostream>
#include <utility>
#include <exception>
#include <string>

//-----------------Queue class------------

template <class Element>
class Queue{

    private: 

        template <class NodeElement>
        struct Node{

            Element m_data;
            Node* m_next; 

            public:

                Node() = default; // default constructor
                ~Node() = default; // d'ctor

                Node(const NodeElement& newElement){  // constructor with parameter - copy constructor

                    m_data = newElement;
                    m_next = nullptr;
                }

                Node& operator=(const Node&) = default; // copy assignment operator - defualt is enough

                
            };

        int m_size;
        Node<Element>* m_front;
        Node<Element>* m_rear;
        

public:

    Queue(); //default constructor

    Queue(const Queue& newQueue); //copy constructor
    ~Queue(); //d'ctor

	void clear(); // clear the queue - delete all the elements - deep delete 

    Queue<Element>& operator=(const Queue<Element>&); //copy assignment operator

    void pushBack(const Element newElement); //insert element to the end of the queue
    
    Element& front(); //return the first element in the queue
    
    const Element& front() const; //return the first element in the queue - const  // why reference?
    
    void popFront(); //remove the first element
    
    int size() const; //return the current size of the queue


    // Iterators zone    
    class Iterator;
    Iterator begin();
    Iterator end();

    class ConstIterator;
    ConstIterator begin() const;
    ConstIterator end() const;


    // Exceptions zone
    class EmptyQueue{};
};



//---------- QUEUE -------------------------

template <class Element>
Queue<Element>::Queue(){ // default constructor

    m_size  = 0;
    m_front = nullptr;
    m_rear = nullptr;
}

template <class Element>
Queue<Element>::Queue(const Queue& copyQueue){ // copy constructor

    if (this == &copyQueue){ // check if the queue is the same queue

        return;
    }

    // reset the queue
    m_size = 0; 
    m_front = nullptr;
    m_rear = nullptr;

    try {

        // running with iterator
        for (Element it : copyQueue){

            try {

                this->pushBack(it); // push the element to the new queue

            }catch(std::bad_alloc& e){ // if we cant allocate memory for the new element, we need to delete the new queue and throw exception
				
                this->clear(); // clear the new queue - delete all the elements - deep delete
				throw std::bad_alloc();
            }

        }

    }catch (typename Queue<Element>::Iterator::InvalidOperation& o){

        this->clear();
        throw typename Queue<Element>::Iterator::InvalidOperation(); // *****************************************************************************************
        
    }catch (typename Queue<Element>::ConstIterator::InvalidOperation& o){

        this->clear();
        throw typename Queue<Element>::ConstIterator::InvalidOperation(); // *****************************************************************************************
        
    }

}


template <class Element>
Queue<Element>::~Queue(){

    if (m_front == nullptr) // if the queue is empty
    {
        return;
    }
	
	for (int i = 0; i<m_size; i++){ // delete all the elements
		
		
		Node<Element>* temp = m_front;
		m_front = m_front->m_next;
		
		delete temp;
		
	}

    // the this pointer is automatically deleted

}


template <class Element>
void Queue<Element>::clear(){ // clear the queue - delete all the elements - deep delete - without delete the this pointer

    if (m_front == nullptr)
    {
        return;
    }
	
	for (int i = 0; i<m_size; i++){ // delete all the elements
		
		
		Node<Element>* temp = m_front;
		m_front = m_front->m_next;
		delete temp;
		
	}
	
	// reset the queue
    m_size = 0;
    m_front = nullptr;
    m_rear = nullptr;

}

template <class Element>
Queue<Element>& Queue<Element>::operator=(const Queue<Element>& copyQueue){ // copy assignment operator

    if (this == &copyQueue){ // check if the queue is the same queue

        return *this;
    }

	// copy the current queue to new queue because we dont want to delete the current queue if we cant allocate memory for the new queue
	Queue<Element>* ThisCopy = new Queue<Element>(*this); 
    this->clear(); // already saved this queue

    try{

        for (Element it : copyQueue){

            try {

                this->pushBack(it);

            }catch(std::bad_alloc& e){
                
                this->clear(); // clear the elements that we already saved

                // copy this to the copy of this we saved earlier
				m_front = ThisCopy->m_front; 
				m_rear = ThisCopy->m_rear;
				m_size = ThisCopy->m_size;

                // delete the copy of this - the copy is only a pointer and it's nodes are still remain
				delete ThisCopy;

				throw std::bad_alloc(); // now we can throw the exception
            }

        }
    }catch (typename Queue<Element>::Iterator::InvalidOperation& o){

        throw typename Queue<Element>::Iterator::InvalidOperation(); 
        
    }catch (typename Queue<Element>::ConstIterator::InvalidOperation& o){

        throw typename Queue<Element>::ConstIterator::InvalidOperation(); 
        
    }

    // delete the copy of this - the copy is only a pointer and it's nodes are still remain
	delete ThisCopy;

    return *this;
}
      

template <class Element>
void Queue<Element>::pushBack(const Element newElement){ // insert element to the end of the queue

	
	Node<Element>* newNode;
	
	try{
	
		newNode = new Node<Element>(newElement);
	
	}catch(std::bad_alloc &e){
		
		throw std::bad_alloc();
	}

    // just taking care of the first element
    if (m_front ==  nullptr){

        m_front = newNode;
        m_rear = newNode;
    } 
    else{

        m_rear->m_next = newNode;
        m_rear = newNode; 
    }

    m_size++; 

}

// this function return the first element in the queue
template <class Element>
Element& Queue<Element>::front(){

    if (m_front == nullptr){

        throw EmptyQueue();
    }

    return(m_front->m_data);
}

// this function return the first element in the queue - const
template <class Element>
const Element& Queue<Element>::front() const{

    if ( m_front == nullptr){

        throw EmptyQueue();
    }
    return(m_front->m_data); 
}

// this function remove the first element in the queue - without return the element
template <class Element>
void Queue<Element>::popFront(){

    if (m_front == nullptr || m_size == 0){ 

        throw EmptyQueue();
    }

    Node<Element>* nodeToDelete = m_front; 
    m_front = m_front->m_next;
    delete nodeToDelete;
    m_size--; 
}

// this function return the size of the queue
template <class Element>
int Queue<Element>::size() const{

    return m_size;
}


// ---------------------- Iterator and ConstIterator begins and ends -------------------------- 
template <class Element>
typename Queue<Element>::Iterator Queue<Element>::begin(){

    return Iterator(this);
}

template <class Element>
typename Queue<Element>::Iterator Queue<Element>::end(){

    Iterator t = (this);
    for(int i = 0; i < m_size; i++){

        try {

            t++;
        
        }catch (typename Queue<Element>::Iterator::InvalidOperation& o){

            throw typename Queue<Element>::Iterator::InvalidOperation(); 
        
        }
    }
    return(t);
}


template <class Element>
typename Queue<Element>::ConstIterator Queue<Element>::begin() const{

    return ConstIterator(this);
}

template <class Element> // add exception -------------------------------------------------------------------------
typename Queue<Element>::ConstIterator Queue<Element>::end() const{

    ConstIterator t = (this);
    for(int i = 0; i < m_size; i++){
        
        try {

            t++;
        
        }catch (typename Queue<Element>::ConstIterator::InvalidOperation& o){

            throw typename Queue<Element>::ConstIterator::InvalidOperation(); 
        
        }

    }
    return(t);
}

// this function take a queue and a comparator and return a new queue with the elements that the comparator return true for them
template<class Element, class C>
Queue<Element> filter(const Queue<Element> &queue ,C comparator){ 

    Queue<Element> filteredQueue; // empty queue of the filtered elements
    
    try {

        for (Element element : queue) // running with the const iterator
        {
            if(comparator(element)){

                try{
                    filteredQueue.pushBack(element);
					
                }catch(std::bad_alloc& e){
						
					filteredQueue.clear();
                }
            }
        }

    }catch (typename Queue<Element>::Iterator::InvalidOperation& o){
            
        throw typename Queue<Element>::Iterator::InvalidOperation();
            
    }catch (typename Queue<Element>::ConstIterator::InvalidOperation& o){

        throw typename Queue<Element>::ConstIterator::InvalidOperation(); 
        
    }

    return filteredQueue;
}


template <class Element, class O>
void transform(Queue<Element> &queue,O operation){

    try{

        for (Element &element : queue) // running with the iterator
        {
            operation(element);
        }

    }catch (typename Queue<Element>::Iterator::InvalidOperation& o){
            
        throw typename Queue<Element>::Iterator::InvalidOperation(); 
            
    }catch (typename Queue<Element>::ConstIterator::InvalidOperation& o){

        throw typename Queue<Element>::ConstIterator::InvalidOperation(); 
        
    }

}


//--------------Iterator------------------


//--------------iterator class----------------

template <class Element>
class Queue<Element>::Iterator{

    private:

        Iterator(const Queue<Element>* queue); 
        Node<Element>* m_current;
        friend class Queue;

    public:
    
        Iterator(const Iterator& copyIterator);
        ~Iterator() = default; // we dont need to delete the iterator, because we dont allocate memory for it

        Element& operator*(); // we can change the value of the element
        Queue<Element>::Iterator& operator++();
        Queue<Element>::Iterator operator++(int);

        bool operator==(const Iterator&) const; // const because we dont want to change the iterator on this operation
        bool operator!=(const Iterator&) const; // const because we dont want to change the iterator on this operation

        class InvalidOperation{}; // we can throw this exception if we want to do something that is not allowed

};


// c'tor of the iterator
template <class Element>
Queue<Element>::Iterator::Iterator(const Queue<Element>* queue){ // get a pointer to the queue, so we send the address, mean send the reference

    if(queue == nullptr){

        throw InvalidOperation();
    }

    m_current = queue->m_front;

}

// copy c'tor of the iterator
template <class Element>
Queue<Element>::Iterator::Iterator(const Iterator& copyIterator){
     
    if(copyIterator.m_current == nullptr){

        throw Queue<Element>::Iterator::InvalidOperation();
    }

    m_current = copyIterator.m_current;
}

// operator * of the iterator
template <class Element>
typename Queue<Element>::Iterator& Queue<Element>::Iterator::operator++(){ // prefix

    if (m_current == nullptr){ // if we are at the end of the queue

        throw Queue<Element>::Iterator::InvalidOperation();
    }
    else {

        m_current = m_current->m_next;
    }
    
    return *this;

}

// operator ++ from the left of the iterator
template <class Element>
typename Queue<Element>::Iterator Queue<Element>::Iterator::operator++(int){
    
    if(m_current == nullptr){

        Queue<Element>::Iterator::InvalidOperation();
    }

    Iterator temp(*this);

    try{
            
        ++(*this);

    }catch (Queue<Element>::Iterator::InvalidOperation& e){
            
        Queue<Element>::Iterator::InvalidOperation();
    }

    return temp;
}

// operator == of the iterator
template <class Element>
bool Queue<Element>::Iterator::operator==(const Iterator& compareIterator) const{
  
    return (this->m_current == compareIterator.m_current);
}

// operator != of the iterator
template <class Element>
bool Queue<Element>::Iterator::operator!=(const Iterator& compareIterator) const{
     
    return !((*this) == compareIterator);
}

// operator * of the iterator  - can change the value of the element - not const
template <class Element>
Element& Queue<Element>::Iterator::operator*(){

    if(m_current == nullptr){

        throw Queue<Element>::Iterator::InvalidOperation();
    }

    return (m_current->m_data);
}


//---------------const iterator class---------

template <class Element>
class Queue<Element>::ConstIterator{

 private:
    
    const Node<Element>* m_current;
    ConstIterator(const Queue<Element>* queue);
    friend class Queue;

 public:
    
    ConstIterator(const Iterator& copyIterator);
    ~ConstIterator() = default;
    const Element& operator*() const; // we can't change the value of the element - const iterator
    Queue<Element>::ConstIterator& operator++();
    Queue<Element>::ConstIterator operator++(int);
    bool operator==(const ConstIterator&) const;
    bool operator!=(const ConstIterator&) const; 

    class InvalidOperation{};

};

//--------------const Iterator------------------

// c'tor of the const iterator
template <class Element>
Queue<Element>::ConstIterator::ConstIterator(const Queue<Element>* queue){
    
    if(queue == nullptr){

        throw Queue<Element>::ConstIterator::InvalidOperation();
    }
    
    m_current = queue->m_front;
}

// copy c'tor of the const iterator
template <class Element>
Queue<Element>::ConstIterator::ConstIterator(const Iterator& copyIterator){

    if(copyIterator.m_current == nullptr){

        throw Queue<Element>::ConstIterator::InvalidOperation();
    }

    m_current = copyIterator.m_current;
}


// operator ++ from the right of the const iterator
template <class Element>
typename Queue<Element>::ConstIterator& Queue<Element>::ConstIterator::operator++(){
    
    if(m_current == nullptr){

        throw Queue<Element>::ConstIterator::InvalidOperation();
    }

    if (m_current == nullptr){

        throw Queue<Element>::ConstIterator::InvalidOperation();
    }
    else {

        m_current = m_current->m_next;
    }

    return *this;

}

// operator ++ from the left of the const iterator
template <class Element>
typename Queue<Element>::ConstIterator Queue<Element>::ConstIterator::operator++(int){

    if(m_current == nullptr){

        throw Queue<Element>::ConstIterator::InvalidOperation();
    }
    
    ConstIterator temp = *this;

    try {
            
        ++(*this);
    
    } catch (Queue<Element>::ConstIterator::InvalidOperation& e){
            
        throw Queue<Element>::ConstIterator::InvalidOperation();
    }

    return temp;

}

// operator == of the const iterator
template <class Element>
bool Queue<Element>::ConstIterator::operator==(const ConstIterator& compareIterator) const{
    
    return (m_current == compareIterator.m_current);
}

// operator != of the const iterator
template <class Element>
bool Queue<Element>::ConstIterator::operator!=(const ConstIterator& compareIterator) const{
     
    return !((*this) == compareIterator);
}

// operator * of the const iterator - can't change the value of the element - const
template <class Element>
const Element& Queue<Element>::ConstIterator::operator*() const{
    
    if(m_current == nullptr){

        throw Queue<Element>::ConstIterator::InvalidOperation();
    }

    return (m_current->m_data);
}


#endif

